package co.com.bancolombia.certificacion.fenix.model.builder;

import co.com.bancolombia.certificacion.fenix.model.Agreement;

public class AgreementBuilder implements Builder<Agreement> {

	private final String code;
	private String socialReason;
	private String idType;
	private String idNumber;
	private String agreementQuota;
	private String cityAgreement;
	private String feePercent;
	private String agreementStatus;
	private String accountType;
	private String agreementAccount;
	private String cardType;
	private String statementType;
	private String bin;
	private String logo;
	private String contactClientName;
	private String contactPhoneNumber;
	private String contactEmail;
	private String executiveManager;
	private String idExecutiveManager;
	
	public AgreementBuilder(String code) {
		this.code = code;
	}
	
	public static AgreementBuilder code(String code) {
		return new AgreementBuilder(code);
	}
	
	public AgreementBuilder socialReason(String socialReason) {
		this.socialReason = socialReason;
		return this;
	}

	public AgreementBuilder accountType(String accountType) {
		this.accountType = accountType;
		return this;
	}

	public AgreementBuilder agreementStatus(String agreementStatus) {
		this.agreementStatus = agreementStatus;
		return this;
	}

	public AgreementBuilder feePercent(String feePercent) {
		this.feePercent = feePercent;
		return this;
	}

	public AgreementBuilder cityAgreement(String cityAgreement) {
		this.cityAgreement = cityAgreement;
		return this;
	}

	public AgreementBuilder bin(String bin) {
		this.bin = bin;
		return this;
	}

	public AgreementBuilder agreementQuota(String agreementQuota) {
		this.agreementQuota = agreementQuota;
		return this;
	}

	public AgreementBuilder statementType(String statementType) {
		this.statementType = statementType;
		return this;
	}

	public AgreementBuilder cardType(String cardType) {
		this.cardType = cardType;
		return this;
	}

	public AgreementBuilder idType(String idType) {
		this.idType = idType;
		return this;
	}

	public AgreementBuilder agreementAccount(String agreementAccount) {
		this.agreementAccount = agreementAccount;
		return this;
	}

	
	public AgreementBuilder idNumber(String idNumber) {
		this.idNumber = idNumber;
		return this;
	}

	public AgreementBuilder logo(String logo) {
		this.logo = logo;
		return this;
	}

	public AgreementBuilder contactClientName(String contactClientName) {
		this.contactClientName = contactClientName;
		return this;
	}

	public AgreementBuilder contactPhoneNumber(String contactPhoneNumber) {
		this.contactPhoneNumber = contactPhoneNumber;
		return this;
	}

	public AgreementBuilder contactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
		return this;
	}

	public AgreementBuilder executiveManager(String executiveManager) {
		this.executiveManager = executiveManager;
		return this;
	}
	public AgreementBuilder idExecutiveManager(String idExecutiveManager) {
		this.idExecutiveManager = idExecutiveManager;
		return this;
	}
	
	@Override
	public Agreement build() {
		return new Agreement(this);
	}

	public String getAgreementQuota() {
		return agreementQuota;

	}
	
	public String getIdNumber() {
		return idNumber;
	}

	public String getCode() {
		return code;
	}
	
	public String getSocialReason() {
		return socialReason;
	}
	
	public String getIdType() {
		return idType;
	}
	
	public String getCityAgreement() {

		return cityAgreement;
	}

	public String getFeePercent() {

		return feePercent;
	}

	public String getAgreementStatus() {

		return agreementStatus;
	}

	public String getAccountType() {

		return accountType;
	}

	public String getAgreementAccount() {
		return agreementAccount;
	}

	public String getCardType() {
		return cardType;
	}

	public String getStatementType() {
		return statementType;
	}

	public String getBin() {
		return bin;
	}

	public String getLogo() {
		return logo;
	}

	public String getContactClientName() {
		return contactClientName;
	}

	public String getContactPhoneNumber() {
		return contactPhoneNumber;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public String getExecutiveManager() {
		return executiveManager;
	}

	public String getIdExecutiveManager() {
		return idExecutiveManager;
	}

}
