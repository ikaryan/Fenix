package co.com.bancolombia.certificacion.fenix.ui;

import org.openqa.selenium.By;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class MemberPage extends PageObject {

	public static final Target MEMBER_TYPE= Target.the("member typelist box").located(By.id("memberType"));
	public static final Target CUSTOMER_NUMBER = Target.the("customer number text area").located(By.id("customerNumber"));
	public static final Target DOCUMENT_TYPE = Target.the("document type list box").located(By.id("documentType"));
	public static final Target DOCUMENT_NUMBER = Target.the("document number text area").located(By.id("documentNumber"));
	public static final Target FIRST_MEMBER_NAME = Target.the("first member name text area").located(By.id("name1"));
	public static final Target SECOND_MEMBER_NAME = Target.the("second member name text area").located(By.id("name2"));
	public static final Target FIRST_MEMBER_LASTNAME = Target.the("first member lastname text area").located(By.id("lastName1"));
	public static final Target SECOND_MEMBER_LASTNAME = Target.the("second member lastname text area").located(By.id("lastName2"));
	public static final Target AGREEMENT_ACCOUNT = Target.the("agreement account text area").located(By.id("account"));
	public static final Target RELATIONSHIP_DOCUMENT = Target.the("relationship docuemnt text area").located(By.id("relationshipDocument"));

}
