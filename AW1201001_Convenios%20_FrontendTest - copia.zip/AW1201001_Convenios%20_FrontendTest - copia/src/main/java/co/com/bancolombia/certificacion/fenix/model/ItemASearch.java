package co.com.bancolombia.certificacion.fenix.model;

public class ItemASearch {
	private String word;
		
	public ItemASearch(String word) {
		this.word = word;
	}

	public String getWord() {
		return word;
	}
	
}
