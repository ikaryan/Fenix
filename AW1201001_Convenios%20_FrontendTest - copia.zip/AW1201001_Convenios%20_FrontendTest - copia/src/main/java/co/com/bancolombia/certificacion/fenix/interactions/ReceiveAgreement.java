package co.com.bancolombia.certificacion.fenix.interactions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;

public class ReceiveAgreement implements Interaction {
	private String socialReason;

	public ReceiveAgreement(String socialReason) {
		this.setSocialReason(socialReason);
	}
	
	
	@Override
	public <T extends Actor> void performAs(T actor) {
		// TODO Auto-generated method stub
		
	}


	public String getSocialReason() {
		return socialReason;
	}


	public void setSocialReason(String socialReason) {
		this.socialReason = socialReason;
	}

}
