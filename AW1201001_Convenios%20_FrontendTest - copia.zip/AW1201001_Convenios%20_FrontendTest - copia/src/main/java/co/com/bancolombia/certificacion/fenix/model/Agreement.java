package co.com.bancolombia.certificacion.fenix.model;

import co.com.bancolombia.certificacion.fenix.model.builder.AgreementBuilder;

public class Agreement {

	private final String code;
	private final String socialReason;
	private final String idType;
	private final String idNumber;
	private final String agreementQuota;
	private final String cityAgreement;
	private final String feePercent;
	private final String agreementStatus;
	private final String accountType;
	private final String agreementAccount;
	private final String cardType;
	private final String statementType;
	private final String bin;
	private final String logo;
	private final String contactClientName;
	private final String contactPhoneNumber;
	private final String contactEmail;
	private final String executiveManager;
	private final String idExecutiveManager;

	public Agreement(AgreementBuilder builder) {
		this.code = builder.getCode();
		this.socialReason = builder.getSocialReason();
		this.idType = builder.getIdType();
		this.idNumber = builder.getIdNumber();
		this.agreementQuota = builder.getAgreementQuota();
		this.cityAgreement = builder.getCityAgreement();
		this.feePercent = builder.getFeePercent();
		this.agreementStatus = builder.getAgreementStatus();
		this.accountType = builder.getAccountType();
		this.agreementAccount = builder.getAgreementAccount();
		this.cardType = builder.getCardType();
		this.statementType = builder.getStatementType();
		this.bin = builder.getBin();
		this.logo = builder.getLogo();
		this.contactClientName = builder.getContactClientName();
		this.contactPhoneNumber = builder.getContactPhoneNumber();
		this.contactEmail = builder.getContactEmail();
		this.executiveManager=builder.getExecutiveManager();
		this.idExecutiveManager=builder.getIdExecutiveManager();
		
	}

	public String getCode() {
		return code;
	}

	public String getSocialReason() {
		return socialReason;
	}

	public String getIdType() {
		return idType;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public String getAgreementQuota() {
		return agreementQuota;
	}

	public String getCityAgreement() {
		return cityAgreement;
	}

	public String getFeePercent() {
		return feePercent;
	}

	public String getAgreementStatus() {
		return agreementStatus;
	}

	public String getAccountType() {
		return accountType;
	}

	public String getAgreementAccount() {
		return agreementAccount;
	}

	public String getCardType() {
		return cardType;
	}

	public String getStatementType() {
		return statementType;
	}

	public String getBin() {
		return bin;
	}

	public String getLogo() {
		return logo;
	}

	public String getContactClientName() {
		return contactClientName;
	}

	public String getContactPhoneNumber() {
		return contactPhoneNumber;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public String getExecutiveManager() {
		return executiveManager;
	}

	public String getIdExecutiveManager() {
		return idExecutiveManager;
	}

}
