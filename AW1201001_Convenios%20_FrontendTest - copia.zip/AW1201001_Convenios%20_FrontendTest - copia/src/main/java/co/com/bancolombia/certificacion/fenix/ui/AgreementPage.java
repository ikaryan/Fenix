package co.com.bancolombia.certificacion.fenix.ui;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("http://localhost:4200/#")
public class AgreementPage extends PageObject {
	
	public static final Target AGREEMENT_MENU = Target.the("agreement menu ").located(By.xpath("/html/body/app-root/div/nav/ul/li[2]/ul/li[1]/button"));
	public static final Target MANAGEMENT_MENU = Target.the("management menu").located(By.xpath("//*[@id=\"menu\"]/li[2]/a"));
	public static final Target AGREEMENT_SUBMENU_MANAGEMENT_MENU = Target.the("agreement submenu maanagement menu").located(By.xpath("//*[@id=\"menu\"]/li[2]/ul/li[1]/button"));
	public static final Target COMMERCE_MENU =Target.the("commerce menu").located(By.xpath("/html/body/app-root/div/nav/ul/li[2]/ul/li[2]/button"));
	public static final Target AGREEMENT_CODE = Target.the("agreement code text area").located(By.id("agreementCode"));
	public static final Target DOCUMENT_TYPE = Target.the("document type list box").located(By.id("documentType"));
	public static final Target AGREEMENT_QUOTA = Target.the("agreement quota text area").located(By.id("agreementQuota"));
	public static final Target FEE_PERCENT = Target.the("fee percent text area").located(By.id("feePercent"));
	public static final Target ACCOUNT_TYPE = Target.the("account type list box").located(By.id("accountType"));
	public static final Target CARD_TYPE = Target.the("card type list box").located(By.id("cardType"));
	public static final Target BIN = Target.the("bin text area").located(By.id("bin"));
	public static final Target COMPANY_NAME = Target.the("company name text area").located(By.id("companyName"));
	public static final Target DOCUMENT_NUMBER = Target.the("document number text area").located(By.id("documentNumber"));
	public static final Target CITY_AGREEMENT = Target.the("city aggreement text area").located(By.id("cityAgreement"));
	public static final Target AGREEMENT_STATUS = Target.the("agreement status list box").located(By.id("agreementStatus"));
	public static final Target AGREEMENT_ACCOUNT = Target.the("agreement account text area").located(By.id("agreementAccount"));
	public static final Target STATEMENT_TYPE =Target.the("statement type list box").located(By.id("statementType"));
	public static final Target LOGO = Target.the("logo text area").located(By.xpath("//input[@id='logo']"));
	public static final Target CONTACT_CLIENT_NAME = Target.the("contact client name text area").located(By.id("contactClientName"));
	public static final Target CONTACT_EMAIL = Target.the("contact email text area").located(By.id("contactEmail"));
	public static final Target ID_EXECUTIVE_MANAGER = Target.the("id executive manager text area").located(By.id("idExecutiveManager"));
	public static final Target CONTACT_PHONE_NUMBER = Target.the("contact phone number text area").located(By.id("contactPhoneNumber"));
	public static final Target EXECUTIVE_MANAGER = Target.the("executive manager text area").located(By.id("executiveManager"));
	public static final Target CLEAR_AGREEMENT = Target.the("clear agreeement button").located(By.id("clearButtonAgreement"));
	public static final Target SUBMIT_AGREEMENT = Target.the("submit agreement button ").located(By.id("submitButtonAgreement"));
	public static final Target AGREEMENT_TABLE = Target.the("agreement table").located(By.xpath("//*[starts-with(@id,'convenios_tb')]/tbody/tr"));
	public static final Target AGREEMENT_MESSAGE_MODAL = Target.the("agreement message modal").located(By.xpath("/html/body/app-root/app-agreement/div[2]"));
	public static final Target CLOSE_AGREEMENT_MODAL = Target.the("close agreement button").located(By.xpath("/html/body/app-root/app-agreement/div[2]/div/a"));
	
	@FindBy(xpath="/html/body/app-root/app-agreement/div[2]")
	public static WebElementFacade agreementMessageModal;
}
	
