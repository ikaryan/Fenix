package co.com.bancolombia.certificacion.fenix.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Hit;
import net.serenitybdd.screenplay.actions.Hover;
import net.serenitybdd.screenplay.targets.Target;

import static co.com.bancolombia.certificacion.fenix.ui.AgreementPage.MANAGEMENT_MENU;
import static net.serenitybdd.screenplay.Tasks.instrumented;

import org.openqa.selenium.Keys;


public class GoToMenu implements Task{

	private Target agreementMenu;
		
	public GoToMenu(Target agreementMenu) {
		this.agreementMenu = agreementMenu;
	}
	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Hover.over(MANAGEMENT_MENU)
						,Click.on(agreementMenu));
		
	}
	
	public static GoToMenu toSubmenu(Target agreementMenuOption) {
		return instrumented(GoToMenu.class, agreementMenuOption);
		
	}

}
