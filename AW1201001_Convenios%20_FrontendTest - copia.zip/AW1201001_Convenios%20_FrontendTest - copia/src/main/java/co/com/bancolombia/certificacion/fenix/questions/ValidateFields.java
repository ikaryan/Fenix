package co.com.bancolombia.certificacion.fenix.questions;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import co.com.bancolombia.certificacion.fenix.util.Constants;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.findby.By;

public class ValidateFields implements Question<Boolean> {
	
	public static String socialReasonAgreement="Country Club6";
	private WebDriver hisBrowser;
		
	@Override
	@Step("It verifies the Agreement list against the whole fields")
	public Boolean answeredBy(Actor actor) {
		
		Boolean result =false;
		List<WebElement> col = hisBrowser.findElements(By.xpath("//*[@id='convenios_tb']/thead/tr/th"));
		List<WebElement> rows = hisBrowser.findElements(By.xpath("//*[@id='convenios_tb']/tbody/tr/td[1]"));
		List<String> dataList = new ArrayList<String>();
		for (int i = 0; i < rows.size(); i++) {

			String tableRow = hisBrowser.findElement(By.xpath("//*[@id='convenios_tb']/tbody/tr[" + (i + 1) + "]")).getText();
			
			if (tableRow.contains(socialReasonAgreement.trim())) {
				for (int x = 0; x < col.size(); x++) {

					String cols = hisBrowser
							.findElement(
									By.xpath("//*[@id='convenios_tb']/tbody/tr[" + (i + 1) + "]/td[" + (x + 1) + "]"))
							.getText();

					dataList.add(cols);
				}
				System.out.println(dataList.get(Constants.ZERO_POS));
				System.out.println(AgreementPage.AGREEMENT_CODE.resolveFor(actor).getTextValue());
				System.out.println(dataList.get(Constants.ONE_POS));
				System.out.println(AgreementPage.COMPANY_NAME.resolveFor(actor).getTextValue());
				System.out.println(dataList.get(Constants.TWO_POS));
				System.out.println(AgreementPage.BIN.resolveFor(actor).getTextValue());
				System.out.println(dataList.get(Constants.THREE_POS));
				System.out.println(AgreementPage.DOCUMENT_NUMBER.resolveFor(actor).getTextValue());
				System.out.println(dataList.get(Constants.FOUR_POS));
				System.out.println(AgreementPage.LOGO.resolveFor(actor).getTextValue());
				System.out.println(dataList.get(Constants.FIVE_POS));
				System.out.println(AgreementPage.AGREEMENT_STATUS.resolveFor(actor).getSelectedValue());
				
				
					if (dataList.get(Constants.ZERO_POS)
							.equals(AgreementPage.AGREEMENT_CODE.resolveFor(actor).getTextValue())
							&& dataList.get(Constants.ONE_POS)
							.equals(AgreementPage.COMPANY_NAME.resolveFor(actor).getTextValue())
							&& dataList.get(Constants.TWO_POS)
							.equals(AgreementPage.BIN.resolveFor(actor).getTextValue())
							&& dataList.get(Constants.THREE_POS)
							.equals(AgreementPage.DOCUMENT_NUMBER.resolveFor(actor).getTextValue())
							&& dataList.get(Constants.FOUR_POS)
							.equals(AgreementPage.LOGO.resolveFor(actor).getTextValue())
							&& dataList.get(Constants.FIVE_POS)
							.equals(AgreementPage.AGREEMENT_STATUS.resolveFor(actor).getSelectedValue())) {
							
							result = true;	
							System.out.println("ingresó en el ciclo");
						}
					break;
			}
		
		}
		return result;
		
	}
	
	public static ValidateFields is() {
		return new ValidateFields();
	}
}
