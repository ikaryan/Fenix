package co.com.bancolombia.certificacion.fenix.util;

import java.util.Timer;
import java.util.TimerTask;

import static net.serenitybdd.screenplay.Tasks.instrumented;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;

public class WaitLoadModal implements Interaction {

	private final WebElementFacade messageModal;
	private final Timer timer; 
	private int seconds;
	
	public WaitLoadModal (WebElementFacade messageModal) {
		this.messageModal= messageModal;
		this.timer = new Timer();
		this.seconds=0;
	}
	class Count extends TimerTask{

		@Override
		public void run() {
			seconds++;			
		}
		
	}
	
	 @Override
	public <T extends Actor> void performAs(T actor) {		 		 
		 while(messageModal.isCurrentlyVisible()||(seconds>180)) {										
			timer.schedule(new Count(),0,100000);	
			
		 }
		 System.out.println("The system delayed to load: " + seconds + " Seconds");
		}

	public static WaitLoadModal of(WebElementFacade messageModal) {
		return instrumented(WaitLoadModal.class, messageModal);
	}


}
