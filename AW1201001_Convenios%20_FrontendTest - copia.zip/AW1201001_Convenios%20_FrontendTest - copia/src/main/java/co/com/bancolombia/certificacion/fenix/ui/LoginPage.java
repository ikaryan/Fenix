package co.com.bancolombia.certificacion.fenix.ui;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("http://icpingress.bancolombia.corp/login")
public class LoginPage extends PageObject{
	
	

}
