package co.com.bancolombia.certificacion.fenix.questions;

import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.thucydides.core.annotations.Step;

public class TheAgreement implements Question<String> {
	AgreementPage agreementPage;

	@Override
	@Step("It verifies the text in the modal agreement")
	public String answeredBy(Actor actor) {

		return AgreementPage.AGREEMENT_MESSAGE_MODAL
				.resolveFor(actor)
				.getText()
				.substring(10, 50)
				.trim();
	}

	public static TheAgreement messageAgreement() {
		return new TheAgreement();
	}

}
