package co.com.bancolombia.certificacion.fenix.model;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class ListAgreement extends PageObject{
	
	private List<Target> tableAgreement;

	public ListAgreement(WebDriver driver) {
		super(driver);
	}
	/*
	public List<Map<String, String>> getListAgreement() {
        return rowsFrom(tableAgreement);
        
    }*/

	private List<Map<String, String>> rowsFrom(List<Target> tableAgreement) {
		return rowsFrom(tableAgreement);
	}

	
	//public ListAgreement(List<Target> tableAgreement) {
		//this.tableAgreement = tableAgreement;
	//}

	
	/*
	this.tblAgreement=builder.getTblAgreement();
	//private final String tblAgreement;
	//public String getTblAgreement() {

		return null;
	}
	
	public String getTblAgreement() {
		return tblAgreement;
	}
	//recibir el target
	public ReadAgreementPage(WebDriver driver) {
        super(driver);
    }
	//ingresar metodo tabla convertir lista elementos
	public List<Map<String, String>> getSearchResults() {
        return rowsFrom(resultTableAgreement);
        
    }
	
	*/

}
