package co.com.bancolombia.certificacion.fenix.model.builder;

public interface Builder <T> {
	T build();
}
