package co.com.bancolombia.certificacion.fenix.tasks;

import java.util.List;

import org.jsoup.select.Evaluator.AllElements;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.steps.Instrumented;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.findby.By;
import static net.serenitybdd.screenplay.Tasks.instrumented;


public class SearchForField implements Interaction{
	
	private String myAgreement;
	
	public SearchForField(String myAgreement) {
		this.myAgreement = myAgreement;
	}
	
	@Override
	@Step("{0} searches for '#keyword' an existing agreement")
	public <T extends Actor> void performAs(T actor) {
		List<WebElementFacade> allAgreement = BrowseTheWeb.as(actor)
				.findAll(By.xpath("//*[starts-with(@id,'convenios_tb')]/tbody/tr"));
		
		for(int i =0; i < allAgreement.size(); i++){
			if(allAgreement.get(i).getText().contains(myAgreement)) {
				actor.attemptsTo(Click.on(allAgreement.get(i)));
				break;
			}
		}
	}
	public static SearchForField of(String socialreason) {
		//return instrumented(SearchForKeyword.class, myAgreement);
		return Instrumented
				.instanceOf(SearchForField.class)
				.withProperties(socialreason);
	}
	
}

