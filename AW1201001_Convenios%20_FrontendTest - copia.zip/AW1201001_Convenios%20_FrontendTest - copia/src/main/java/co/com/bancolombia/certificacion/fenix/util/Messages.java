package co.com.bancolombia.certificacion.fenix.util;

import org.apache.tools.ant.filters.TokenFilter.Trim;

public class Messages {
	public static String guardadoExitosoConvenio = "El convenio se ha agregado exitosamente";
	
}
