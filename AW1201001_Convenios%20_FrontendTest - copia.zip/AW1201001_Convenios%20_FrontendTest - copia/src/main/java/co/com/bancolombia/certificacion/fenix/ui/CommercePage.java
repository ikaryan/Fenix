package co.com.bancolombia.certificacion.fenix.ui;

import org.openqa.selenium.By;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class CommercePage extends PageObject {
	public static final Target AGREEMENT_CODE = Target.the("agreement code list box ").located(By.id("companyName"));
	public static final Target COMPANY_NAME = Target.the("company name text area").located(By.id("companyName"));	
	public static final Target SAVE_COMMERCE = Target.the("save commerce button").located(By.id("saveButtonCommerce"));
	public static final Target DELETE_COMMERCE = Target.the("delete commerce button").located(By.id("deleteButtonCommerce"));
	public static final Target CLEAR_COMMERCE = Target.the("clear commerce button").located(By.id("clearButtonCommerce"));
	public static final Target COMMERCE_TABLE = Target.the("commerce table").located(By.id("comercios_tb"));

}
