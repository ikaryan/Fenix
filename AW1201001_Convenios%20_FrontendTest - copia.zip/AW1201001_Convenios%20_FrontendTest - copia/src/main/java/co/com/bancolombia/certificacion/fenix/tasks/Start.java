package co.com.bancolombia.certificacion.fenix.tasks;

import static net.serenitybdd.screenplay.Tasks.instrumented;

import org.assertj.core.util.Lists;

import co.com.bancolombia.certificacion.fenix.model.User;
import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import net.serenitybdd.core.steps.Instrumented;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Open;

public class Start implements Task{
	
	private final User user;
	private AgreementPage agreementpage;
	
	public Start(User user) {
		this.user = user;
	}
	
	public static Start withAuthenticatedUser(User user) {
		return instrumented(Start.class, user);
	}
	
	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Open.browserOn(agreementpage));
		// TODO cuando se implemente el login por parte de desarrollo se debe actualizar esta tarea
	}

}
