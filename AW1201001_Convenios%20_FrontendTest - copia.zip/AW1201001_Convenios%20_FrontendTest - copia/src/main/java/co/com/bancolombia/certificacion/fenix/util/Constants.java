package co.com.bancolombia.certificacion.fenix.util;

public abstract class Constants {
	
	public static final int ZERO_POS = 0;
	public static final int ONE_POS = 1;
	public static final int TWO_POS = 2;
	public static final int THREE_POS = 3;
	public static final int FOUR_POS = 4;
	public static final int FIVE_POS = 5;
	public static final int SIX_POS = 6;
	public static final int SEVEN_POS = 7;
	public static final int EIGHT_POS= 8;
	public static final int NINE_POS = 9;
	public static final int TEN_POS = 10;
	public static final int ELEVEN_POS = 11;
	public static final int TWELVE_POS = 12;
	public static final int THIRTEEN_POS = 13;
	public static final int FOURTEEN_POS = 14;
	public static final int FIFTEEN_POS = 15;
	public static final int SIXTEEN_POS = 16;
	public static final int SEVENTEEN_POS = 17;
	public static final int EIGHTEEN_POS = 18;
	public static final int NINETEEN_POS = 18;
	public static final int SIZE_RD = 9999;
	
}
