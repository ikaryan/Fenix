package co.com.bancolombia.certificacion.fenix.tasks;

import co.com.bancolombia.certificacion.fenix.model.Agreement;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.SelectFromOptions;
import static co.com.bancolombia.certificacion.fenix.ui.AgreementPage.*;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class CreateAgreement implements Task {
	
	private final Agreement agreement;
	
	public CreateAgreement(Agreement agreement) {
		this.agreement = agreement;
	}
	
	public static CreateAgreement withFollowingData(Agreement agreement) {
		return instrumented(CreateAgreement.class, agreement);
	}
		
	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Enter.theValue(agreement.getCode()).into(AGREEMENT_CODE),
				SelectFromOptions.byVisibleText(agreement.getIdType()).from(DOCUMENT_TYPE),
				Enter.theValue("" + agreement.getAgreementQuota()).into(AGREEMENT_QUOTA),
				Enter.theValue("" + agreement.getFeePercent()).into(FEE_PERCENT),
				SelectFromOptions.byVisibleText(agreement.getAccountType()).from(ACCOUNT_TYPE),
				SelectFromOptions.byVisibleText(agreement.getCardType()).from(CARD_TYPE),
				Enter.theValue(agreement.getBin()).into(BIN),
				Enter.theValue(agreement.getSocialReason()).into(COMPANY_NAME),
				Enter.theValue(agreement.getIdNumber()).into(DOCUMENT_NUMBER),
				Enter.theValue(agreement.getCityAgreement()).into(CITY_AGREEMENT),
				SelectFromOptions.byVisibleText(agreement.getAgreementStatus()).from(AGREEMENT_STATUS),
				Enter.theValue("" + agreement.getAgreementAccount()).into(AGREEMENT_ACCOUNT),
				SelectFromOptions.byVisibleText(agreement.getStatementType()).from(STATEMENT_TYPE),
				Enter.theValue(agreement.getLogo()).into(LOGO),
				Enter.theValue(agreement.getContactClientName()).into(CONTACT_CLIENT_NAME),
				Enter.theValue(agreement.getContactEmail()).into(CONTACT_EMAIL),
				Enter.theValue(agreement.getIdExecutiveManager()).into(ID_EXECUTIVE_MANAGER),
				Enter.theValue(agreement.getContactPhoneNumber()).into(CONTACT_PHONE_NUMBER),
				Enter.theValue(agreement.getExecutiveManager()).into(EXECUTIVE_MANAGER));
		}
	
}


