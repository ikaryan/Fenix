package co.com.bancolombia.certificacion.fenix.tasks;

import static net.serenitybdd.screenplay.Tasks.instrumented;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import co.com.bancolombia.certificacion.fenix.model.ItemASearch;
import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.thucydides.core.annotations.findby.By;

@SuppressWarnings("deprecation")
public class QueryAgreement implements Task {

	private ItemASearch itemSearch;
	WebElement hisBrowser;
	String convenio = "juana la loca";

	public QueryAgreement(ItemASearch itemSearch) {
		this.itemSearch = itemSearch;
	}
	
	@Override
	public <T extends Actor> void performAs(T actor) {
		List<String> dataField = new ArrayList<String>();
        List<WebElement> col = hisBrowser.findElements(By.xpath("//*[@id='convenios_tb']/thead/tr/th"));
		List<WebElement> rows = hisBrowser.findElements(By.xpath("//*[@id='convenios_tb']/tbody/tr/td[1]"));
        
		for (int i = 0; i < rows.size(); i++) {
			String tableRow = hisBrowser.findElement(By.xpath("//*[@id='convenios_tb']/tbody/tr[" + (i + 1) + "]"))
					.getText();
			if (tableRow.contains(itemSearch.getWord().trim())) {
				for (int x = 0; x < col.size(); x++) {
					String cols = hisBrowser
							.findElement(By.xpath("//*[@id='convenios_tb']/tbody/tr[" + (i + 1) + "]/td[" + (x + 1) + "]"))
							.getText();
					dataField.add(cols);
				}
				
				if (dataField.get(0).equals(AgreementPage.AGREEMENT_CODE.resolveFor(actor).getTextValue())
						&& dataField.get(1).equals(AgreementPage.COMPANY_NAME.resolveFor(actor).getTextValue())
						&& dataField.get(2).equals(AgreementPage.BIN.resolveFor(actor).getTextValue())
						&& dataField.get(3).equals(AgreementPage.DOCUMENT_NUMBER.resolveFor(actor).getTextValue())
						&& dataField.get(4).equals(AgreementPage.LOGO.resolveFor(actor).getTextValue())
						&& dataField.get(5).equals(AgreementPage.AGREEMENT_STATUS.resolveFor(actor).getSelectedValue())) {
				}
				break;
			}
		}
   	}

	public static QueryAgreement the(ItemASearch itemSearch) {
		return instrumented(QueryAgreement.class, itemSearch);

	}
}
