package co.com.bancolombia.certificacion.fenix.questions;

import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class MessageError implements Question<String>{
	

	@Override
	public String answeredBy(Actor actor) {
		//pending the message generate for developers
		return AgreementPage.AGREEMENT_MESSAGE_MODAL.resolveFor(actor).getText();
	}
	
	public static MessageError name() {
		return new MessageError();
	}
}
