package co.com.bancolombia.certificacion.fenix.step_definitions;

import org.openqa.selenium.WebDriver;

import co.com.bancolombia.certificacion.fenix.model.User;
import co.com.bancolombia.certificacion.fenix.tasks.GoToMenu;
import co.com.bancolombia.certificacion.fenix.tasks.Start;
import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.thucydides.core.annotations.Managed;

public class QueryAgreementSuccessFullyStepDefinition {

	@Managed(driver = "chrome")
	private WebDriver hisBrowser;
	AgreementPage agreementPage;

	private Actor manuela = Actor.named("Manuela");

	@Before
	public void manuelaCanBrowseTheWeb() {
		manuela.can(BrowseTheWeb.with(hisBrowser));

	}

	@Given("^que requiero consultar un convenio existente$")
	public void thaIsRequiredToReadExistedAgreement() throws Exception {
		User user = new User("", "");
		manuela.attemptsTo(Start.withAuthenticatedUser(user));
		manuela.attemptsTo(GoToMenu.toSubmenu(AgreementPage.AGREEMENT_SUBMENU_MANAGEMENT_MENU));
		// manuela.attemptsTo(Click.on(QueryAgreement.the(CONVENIOS_TABLE)));

	}

	@When("^selecciono un registro de la lista$")
	public void selecciono_un_registro_de_la_lista(DataTable arg1) throws Exception {

	}

	@Then("^logro visualizar la informacion del convenio seleccionado$")
	public void logro_visualizar_la_informacion_del_convenio_seleccionado() throws Exception {

	}
}
