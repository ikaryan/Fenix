package co.com.bancolombia.certificacion.fenix.step_definitions;

import static co.com.bancolombia.certificacion.fenix.model.builder.AgreementBuilder.*;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import co.com.bancolombia.certificacion.fenix.model.User;
import co.com.bancolombia.certificacion.fenix.questions.TheAgreement;
import co.com.bancolombia.certificacion.fenix.questions.ValidateFields;
import co.com.bancolombia.certificacion.fenix.tasks.GoToMenu;
import co.com.bancolombia.certificacion.fenix.tasks.ModifyAgreement;
import co.com.bancolombia.certificacion.fenix.tasks.SearchForField;
import co.com.bancolombia.certificacion.fenix.tasks.Start;
import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import co.com.bancolombia.certificacion.fenix.util.Constants;
import co.com.bancolombia.certificacion.fenix.util.Messages;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.findby.By;

public class ModifyAgreementStepDefinitions {

	@Managed
	private WebDriver hisBrowser;
	private Actor fenixUser = Actor.named("FenixUser");
	AgreementPage agreementpage;
	public static String socialReasonAgreement="Country Club9";
		
	@Before
	public void fenixUserCanBrowseTheWeb() throws Exception {
		fenixUser.can(BrowseTheWeb.with(hisBrowser));

	}

	@Given("^that it is required to modify an existing agreement$")
	public void thatItRequiredToModifyAnExistingAgreement() throws Exception {
		User user = new User("", "");
		fenixUser.attemptsTo(Start.withAuthenticatedUser(user));
		fenixUser.attemptsTo(GoToMenu.toSubmenu(AgreementPage.AGREEMENT_SUBMENU_MANAGEMENT_MENU));
		
	}

	@And("^A specific agreement is selected of the agreement list$")
	public void theAgreementIsSeletedAgreementList(List<String> dataAgreement) throws Exception{
		fenixUser.attemptsTo(SearchForField.of(dataAgreement.get(Constants.ZERO_POS)));
		
	}
	
	@When("^the info to modify is entered in every field$")
	public void theInfoToModifyIsEntered(List<String> data) throws Exception {
		//manuela.wasAbleTo(Click.on(QueryAgreement.the(i)));
		fenixUser.attemptsTo(ModifyAgreement.withFollowingData(code(data.get(Constants.EIGHTEEN_POS))
				.socialReason(data.get(Constants.ZERO_POS))
				.idType(data.get(Constants.ONE_POS))
				.idNumber(data.get(Constants.TWO_POS))
				.agreementQuota(data.get(Constants.THREE_POS))
				.cityAgreement(data.get(Constants.FOUR_POS))
				.feePercent(data.get(Constants.FIVE_POS))
				.agreementStatus(data.get(Constants.SIX_POS))
				.accountType(data.get(Constants.SEVEN_POS))
				.agreementAccount(data.get(Constants.EIGHT_POS))
				.cardType(data.get(Constants.NINE_POS))
				.statementType(data.get(Constants.TEN_POS))
				.bin(data.get(Constants.ELEVEN_POS))
				.logo(data.get(Constants.TWELVE_POS))
				.contactClientName(data.get(Constants.THIRTEEN_POS))
				.contactPhoneNumber(data.get(Constants.FOURTEEN_POS))
				.contactEmail(data.get(Constants.FIFTEEN_POS))
				.executiveManager(data.get(Constants.SIXTEEN_POS))
				.idExecutiveManager(data.get(Constants.SEVENTEEN_POS))
				.build()));
		
		Boolean result =false;
		List<WebElement> col = hisBrowser.findElements(By.xpath("//*[@id='convenios_tb']/thead/tr/th"));
		List<WebElement> rows = hisBrowser.findElements(By.xpath("//*[@id='convenios_tb']/tbody/tr/td[1]"));
		List<String> dataList = new ArrayList<String>();
		for (int i = 0; i < rows.size(); i++) {

			String tableRow = hisBrowser.findElement(By.xpath("//*[@id='convenios_tb']/tbody/tr[" + (i + 1) + "]")).getText();
			
			if (tableRow.contains(socialReasonAgreement.trim())) {
				for (int x = 0; x < col.size(); x++) {

					String cols = hisBrowser
							.findElement(
									By.xpath("//*[@id='convenios_tb']/tbody/tr[" + (i + 1) + "]/td[" + (x + 1) + "]"))
							.getText();

					dataList.add(cols);
				}
				System.out.println(dataList.get(Constants.ZERO_POS));
				System.out.println(AgreementPage.AGREEMENT_CODE.resolveFor(fenixUser).getTextValue());
				System.out.println(dataList.get(Constants.ONE_POS));
				System.out.println(AgreementPage.COMPANY_NAME.resolveFor(fenixUser).getTextValue());
				System.out.println(dataList.get(Constants.TWO_POS));
				System.out.println(AgreementPage.BIN.resolveFor(fenixUser).getTextValue());
				System.out.println(dataList.get(Constants.THREE_POS));
				System.out.println(AgreementPage.DOCUMENT_NUMBER.resolveFor(fenixUser).getTextValue());
				System.out.println(dataList.get(Constants.FOUR_POS));
				System.out.println(AgreementPage.LOGO.resolveFor(fenixUser).getTextValue());
				System.out.println(dataList.get(Constants.FIVE_POS));
				System.out.println(AgreementPage.AGREEMENT_STATUS.resolveFor(fenixUser).getSelectedValue());
				
				
					if (dataList.get(Constants.ZERO_POS)
							.equals(AgreementPage.AGREEMENT_CODE.resolveFor(fenixUser).getTextValue())
							&& dataList.get(Constants.ONE_POS)
							.equals(AgreementPage.COMPANY_NAME.resolveFor(fenixUser).getTextValue())
							&& dataList.get(Constants.TWO_POS)
							.equals(AgreementPage.BIN.resolveFor(fenixUser).getTextValue())
							&& dataList.get(Constants.THREE_POS)
							.equals(AgreementPage.DOCUMENT_NUMBER.resolveFor(fenixUser).getTextValue())
							&& dataList.get(Constants.FOUR_POS)
							.equals(AgreementPage.LOGO.resolveFor(fenixUser).getTextValue())
							&& dataList.get(Constants.FIVE_POS)
							.equals(AgreementPage.AGREEMENT_STATUS.resolveFor(fenixUser).getSelectedValue())) {
							
							result = true;	
							System.out.println("ingresó en el ciclo" + result);
						}
					break;
			}
		
		}
		//return result;
		
	
		
		fenixUser.should(seeThat(ValidateFields.is(),Matchers.e(true)));
		fenixUser.wasAbleTo(Click.on(AgreementPage.SUBMIT_AGREEMENT));
	}
	
	@Then("^successful creation message will be displayed in screen$")
	public void successfulCreationMessageWillBeDisplayed() throws Exception {
		//manuela.wasAbleTo(WaitLoadModal.of(AgreementPage.agreementMessageModal));
		fenixUser.should(
				seeThat(TheAgreement.messageAgreement(), CoreMatchers.equalTo(Messages.guardadoExitosoConvenio)));
		fenixUser.wasAbleTo
					(Click.on(AgreementPage.CLOSE_AGREEMENT_MODAL));

	}

	@And("^the modified record is visualized by screen$")
	public void theModifiedRecordIsVisualizedByScreen() throws Exception {
		System.out.println("el valor de result es:" + ValidateFields.is());
		//manuela.should(seeThat(ValidateFields.is(),CoreMatchers.equalTo(true)));
		
	}
		
}
