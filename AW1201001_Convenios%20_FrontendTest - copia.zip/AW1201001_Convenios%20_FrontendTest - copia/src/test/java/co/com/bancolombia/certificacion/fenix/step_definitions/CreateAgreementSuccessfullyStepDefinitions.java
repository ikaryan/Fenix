package co.com.bancolombia.certificacion.fenix.step_definitions;

import static co.com.bancolombia.certificacion.fenix.model.builder.AgreementBuilder.*;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import java.util.List;
import java.util.Random;
import org.hamcrest.CoreMatchers;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import co.com.bancolombia.certificacion.fenix.model.User;
import co.com.bancolombia.certificacion.fenix.questions.TheAgreement;
import co.com.bancolombia.certificacion.fenix.tasks.CreateAgreement;
import co.com.bancolombia.certificacion.fenix.tasks.GoToMenu;
import co.com.bancolombia.certificacion.fenix.tasks.Start;
import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import co.com.bancolombia.certificacion.fenix.util.Constants;
import co.com.bancolombia.certificacion.fenix.util.Messages;
import cucumber.api.java.Before;
import cucumber.api.java.en.*;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.thucydides.core.annotations.Managed;

public class CreateAgreementSuccessfullyStepDefinitions {
	
	Random rd = new Random();
	
	@Managed
	private WebDriver hisBrowser;
	AgreementPage agreementPage;
	String pathToExtension = "C:\\Users\\Administrador\\AppData\\Local\\Google\\Chrome\\User Data\\"
			+ "Default\\Extensions\\nlfbmbojpeacfghkpbjhddihlkkiljbi\\1.0.3_0";

	ChromeOptions options = new ChromeOptions();
	private Actor fenixUser = Actor.named("FenixUser");

	@Before
	public void fenixUserCanBrowseTheWeb() {
		options.addArguments("--load-extension=" + pathToExtension, "--start-maximized");
		hisBrowser = new ChromeDriver(options);
		fenixUser.can(BrowseTheWeb.with(hisBrowser));

	}

	@Given("^that is required to add a new agreement$")
	public void thatIsRequiredToAddNewAgreement() throws Exception {
		User user = new User("", "");
		fenixUser.attemptsTo(Start.withAuthenticatedUser(user));
		fenixUser.attemptsTo(GoToMenu.toSubmenu(AgreementPage.AGREEMENT_SUBMENU_MANAGEMENT_MENU));

	}

	@When("^the information is entered in all fields of the form$")
	public void theInfoIsEnteredInAllFieldsForm(List<String> data) throws Exception {
		fenixUser.attemptsTo(CreateAgreement.withFollowingData(code(data.get(Constants.ZERO_POS) + rd.nextInt(Constants.SIZE_RD))
				.socialReason(data.get(Constants.ONE_POS))
				.idType(data.get(Constants.TWO_POS))
				.idNumber(data.get(Constants.THREE_POS))
				.agreementQuota(data.get(Constants.FOUR_POS))
				.cityAgreement(data.get(Constants.FIVE_POS))
				.feePercent(data.get(Constants.SIX_POS))
				.agreementStatus(data.get(Constants.SEVEN_POS))
				.accountType(data.get(Constants.EIGHT_POS))
				.agreementAccount(data.get(Constants.NINE_POS))
				.cardType(data.get(Constants.TEN_POS))
				.statementType(data.get(Constants.ELEVEN_POS))
				.bin(data.get(Constants.TWELVE_POS))
				.logo(data.get(Constants.THIRTEEN_POS))
				.contactClientName(data.get(Constants.FOURTEEN_POS))
				.contactPhoneNumber(data.get(Constants.FIFTEEN_POS))
				.contactEmail(data.get(Constants.SIXTEEN_POS))
				.executiveManager(data.get(Constants.SEVENTEEN_POS))
				.idExecutiveManager(data.get(Constants.EIGHTEEN_POS))
				.build()));
		
		fenixUser.wasAbleTo(Click.on(AgreementPage.SUBMIT_AGREEMENT));
	}

	@Then("^successful creation message will be displayed$")
	public void successfulCreationMessageWillBeDisplayed() throws Exception {
		//manuela.wasAbleTo(WaitLoadModal.of(AgreementPage.agreementMessageModal));
		fenixUser.should(
				seeThat(TheAgreement.messageAgreement(), CoreMatchers.equalTo(Messages.guardadoExitosoConvenio)));
		fenixUser.wasAbleTo
					(Click.on(AgreementPage.CLOSE_AGREEMENT_MODAL));

	}

}
