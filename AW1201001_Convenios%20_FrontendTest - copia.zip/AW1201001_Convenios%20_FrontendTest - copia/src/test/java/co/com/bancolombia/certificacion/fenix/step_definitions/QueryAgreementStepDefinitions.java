package co.com.bancolombia.certificacion.fenix.step_definitions;

import java.util.List;

import org.mockito.internal.matchers.StartsWith;
import org.openqa.selenium.WebDriver;

import co.com.bancolombia.certificacion.fenix.model.User;
import co.com.bancolombia.certificacion.fenix.tasks.GoToMenu;
import co.com.bancolombia.certificacion.fenix.tasks.Start;
import co.com.bancolombia.certificacion.fenix.ui.AgreementPage;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.questions.Text;
import net.thucydides.core.annotations.Managed;

public class QueryAgreementStepDefinitions {
	
	@Managed
	private WebDriver hisBrowser;
	Actor manuela = Actor.named("Manuela");
	AgreementPage agreementPage;
	
	@Before
	public void manuelaCanBrowseTheWeb() {
		manuela.can(BrowseTheWeb.with(hisBrowser));
	}
	
	@Given("^that I required to query a existing agreement$")
	public void thatIRequiredToQueryAExistingAgreement() throws Exception {
		User user = new User("", "");
		manuela.attemptsTo(Start.withAuthenticatedUser(user));
		manuela.attemptsTo(GoToMenu.toSubmenu(AgreementPage.AGREEMENT_SUBMENU_MANAGEMENT_MENU));
		
	}
	
	@When("^I click on an existing agreement in screen$")
	public void iClickOnAnExistingAgreementInScreen(List<String> data) throws Exception {
		//manuela.wasAbleTo(Click.on(target));
		List convenio =  Text.of(agreementPage.AGREEMENT_TABLE)
				.viewedBy(manuela)
				.asList();
		
		System.out.println("el resultado del convenio es" + convenio);
	}
}
